# models/network/litemono/litemono.py
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

# 這兩個就是你從 Lite-Mono 複進來的檔案
from .third_party.litemono.networks.resnet_encoder import ResnetEncoder
from .third_party.litemono.networks.depth_decoder import DepthDecoder


class LiteMonoDepth(nn.Module):
    """
    包裝 Lite-Mono 的 ResnetEncoder + DepthDecoder，給主專案使用。
    - 支援 LWIR 1ch（可複製為 3ch）
    - forward(image[B,1/3,H,W]) -> depth[B,1,H,W]
    """

    def __init__(self,
                 in_channels: int = 1,
                 repeat_gray_to_rgb: bool = True,
                 min_depth: float = 1e-3,
                 max_depth: float = 80.0,
                 resnet_layers: int = 18,
                 pretrained_backbone: bool = False):
        super().__init__()
        self.min_depth = float(min_depth)
        self.max_depth = float(max_depth)
        self.repeat_gray_to_rgb = bool(repeat_gray_to_rgb)

        # Encoder（Lite-Mono / Monodepth2 風格）
        self.encoder = ResnetEncoder(
            num_layers=resnet_layers, pretrained=pretrained_backbone)
        # e.g. [64, 64, 128, 256, 512]
        enc_ch = self.encoder.num_ch_enc
        num_ch_enc_dec = np.array(
            [enc_ch[2], enc_ch[3], enc_ch[4]], dtype=int)  # -> [128,256,512]

        # 這裡關鍵：scales=range(3)
        self.decoder = DepthDecoder(num_ch_enc=num_ch_enc_dec, scales=range(
            3), num_output_channels=1, use_skips=True)

    @torch.no_grad()
    def _prep_input(self, x: torch.Tensor) -> torch.Tensor:
        # 1ch → 3ch（若你改了第一層成 1ch，則把 repeat_gray_to_rgb 設 False）
        if x.size(1) == 1 and self.repeat_gray_to_rgb:
            x = x.repeat(1, 3, 1, 1)
        return x

    def _disp_to_depth(self, disp: torch.Tensor) -> torch.Tensor:
        """
        將 disparity（已是 0~1）映射到深度範圍 [min_depth, max_depth]。
        注意：若你的 decoder 已直接回 depth，就改成 `return disp`。
        """
        min_d, max_d = self.min_depth, self.max_depth
        # 不要再 sigmoid，一般 decoder 內已做過
        depth = 1.0 / (disp * (1.0 / min_d - 1.0 / max_d) + 1.0 / max_d)
        return depth

    def forward(self, image: torch.Tensor) -> torch.Tensor:
        """
        image: (B,1,H,W) or (B,3,H,W)
        return: depth: (B,1,H,W)
        """
        B, C, H, W = image.shape
        x = self._prep_input(image)

        feats = self.encoder(x)              # list of pyramid features

        feats = list(self.encoder(x))  # 預期是 [H/2, H/4, H/8, H/16, H/32]
        # 取出 [H/8, H/16, H/32]，順序就是 [淺→深] = [feats[2], feats[3], feats[4]]
        inp = [feats[2], feats[3], feats[4]]
        outputs = self.decoder(inp)

        # 取最高解析度的 disparity。大多數實作是 dict，key 為 ("disp", 0)
        disp = None
        if isinstance(outputs, dict):
            if ("disp", 0) in outputs:
                disp = outputs[("disp", 0)]
            elif "disp" in outputs:
                d = outputs["disp"]
                if isinstance(d, dict):
                    # 優先拿 0；不行就拿第一個 value
                    disp = d.get(0) or d.get("0") or next(iter(d.values()))
                else:
                    disp = d
            else:
                # 退而求其次：拿第一個 value
                disp = next(iter(outputs.values()))
        elif isinstance(outputs, (list, tuple)):
            disp = outputs[0]
        else:
            disp = outputs

        # 保證是 (B,1,h,w) 的張量
        if isinstance(disp, dict):
            disp = next(iter(disp.values()))
        if disp.dim() == 3:
            disp = disp.unsqueeze(1)
        elif disp.dim() == 4 and disp.size(1) != 1:
            disp = disp[:, :1, ...]

        # disparity → depth（標準映射）
        depth = 1.0 / (torch.sigmoid(disp) * (1.0 / self.min_depth -
                       1.0 / self.max_depth) + 1.0 / self.max_depth)
        if depth.shape[-2:] != (H, W):
            depth = F.interpolate(depth, size=(
                H, W), mode="bilinear", align_corners=False)
        depth = depth.clamp(min=self.min_depth, max=self.max_depth)
        return depth
